import { Fragment } from 'react'

const Shortlisted = () => {
    return (
        <Fragment>
            <h1>Shortlisted Candidates</h1>
        </Fragment>
    )
}

export default Shortlisted