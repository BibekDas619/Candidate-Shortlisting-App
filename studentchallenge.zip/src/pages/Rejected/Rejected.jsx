import { Fragment } from 'react'

const Rejected = () => {
    return (
        <Fragment>
            <h1>Rejected Candidates</h1>
        </Fragment>
    )
}

export default Rejected