import { Fragment } from 'react'
import { HeaderTabsWrapper, HeaderTabsContainer, TabStyle } from './Header.styles'

const Header = () => {
    return (
        <Fragment>
            <HeaderTabsWrapper>
                <HeaderTabsContainer>
                    <TabStyle type="Shortlisted">Shortlisted</TabStyle>
                    <TabStyle type="Rejected">Rejected</TabStyle>
                </HeaderTabsContainer>
            </HeaderTabsWrapper>
        </Fragment>
    )
}

export default Header