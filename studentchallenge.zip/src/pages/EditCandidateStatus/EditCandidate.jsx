import { Fragment } from 'react'
import { useParams } from 'react-router-dom'
import { connect } from 'react-redux'
import { changeStatusToRejected, changeStatusToShortlisted } from '../../redux/CandidateRedux/Candidate.actions'

const EditCandidate = ({ allCandidates, shortlisted, rejected }) => {

    const { id } = useParams()

    const specificCandidateDetails = allCandidates.filter(data => data.id === id)[0]
    console.log(specificCandidateDetails)

    return (
        <Fragment>
            <h1>Edit Candidate {id}</h1>
            <button onClick={() => shortlisted(id)}>Shortlisted</button>
            <button onClick={() => rejected(id)}>Rejected</button>
        </Fragment>
    )
}

const mapStateToProps = state => ({
    allCandidates: state.candidates.data
})

const mapDispatchToProps = dispatch => ({
    shortlisted: (id) => dispatch(changeStatusToShortlisted(id)),
    rejected: (id) => dispatch(changeStatusToRejected(id))
})

export default connect(mapStateToProps, mapDispatchToProps)(EditCandidate)